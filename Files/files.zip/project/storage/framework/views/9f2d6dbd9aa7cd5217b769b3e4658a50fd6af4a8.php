<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">

            <div class="row" id="main">

                <div class="go-title">
                    <h3>Pending Campaigns</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="res">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                    <!-- Page Content -->
                            <table class="table table-striped table-bordered" cellspacing="0" id="example" width="100%">
                                <thead>
                                <tr>
                                    <th width="20%">Campaign Name</th>
                                    <th>Date</th>
                                    <th>Goal</th>
                                    <th>Created By</th>
                                    <th>Category</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($campaign->title); ?></td>
                                        <td><?php echo e(date('d M',strtotime($campaign->created_at))); ?> - <?php echo e(date('d M',strtotime($campaign->end_date))); ?></td>
                                        <td>$<?php echo e($campaign->goal); ?></td>
                                        <td><?php echo e($campaign->createdby->name); ?></td>
                                        <td><?php echo e($campaign->category); ?></td>
                                        <td>
                                            <a href="<?php echo e($campaign->id); ?>/pending" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> View </a>
                                            <a href="<?php echo e($campaign->id); ?>/accept" class="btn btn-primary btn-xs"><i class="fa fa-check"></i> Accept </a>

                                            <a href="javascript:;" data-title="Reject Campaign" data-href="<?php echo e(url('/')); ?>/admin/campaign/<?php echo e($campaign->id); ?>/reject" data-toggle="modal" data-target="#confirm" class="btn btn-warning btn-xs"><i class="fa fa-times"></i> Reject </a>

                                            <a href="javascript:;" data-title="Reject & Delete Campaign" data-href="<?php echo e(url('/')); ?>/admin/campaign/<?php echo e($campaign->id); ?>/hardreject" data-toggle="modal" data-target="#confirm" class="btn btn-danger btn-xs"><i class="fa fa-trash"></i> Reject & Delete </a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

    <div class="modal fade" id="confirm" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content panel-danger">
                <div class="modal-header panel-heading">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title" id="myModalLabel"></h3>
                </div>
                <div class="modal-body">
                    <h4>Do you want to proceed?</h4>
                    <form method="GET" action="" id="reform" class="form-horizontal form-label-left">
                        <div class="item form-group">
                            <div class="col-md-12 col-sm-12 col-xs-12">
                                <textarea placeholder="Reject Reason(Required)" rows="6" name="reason" class="form-control" required></textarea>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-3">
                                <button type="submit" class="btn btn-primary btn-block btn-ok">Reject</button>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $('#confirm').on('show.bs.modal', function(e) {
            $(this).find('#reform').attr('action', $(e.relatedTarget).data('href'));
            $(this).find('#myModalLabel').html($(e.relatedTarget).data('title'));
            $(this).find('.btn-ok').html($(e.relatedTarget).data('title'));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>