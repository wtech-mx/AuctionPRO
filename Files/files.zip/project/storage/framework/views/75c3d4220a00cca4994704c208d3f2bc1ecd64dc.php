

<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('admin/users'); ?>" class="btn btn-default btn-add"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <h3>User Details</h3>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">

                        <table class="table">
                            <tbody>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>User ID#</strong></td>
                                <td><?php echo e($customer->id); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Account Status: </strong></td>
                                <?php if($customer->status != 0): ?>
                                    <td style="color: #008000;"> <strong>Active</strong></td>
                                <?php else: ?>
                                    <td style="color: #ff0000;"><strong>Banned</strong></td>
                                <?php endif; ?>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>User Name:</strong></td>
                                <td><?php echo e($customer->name); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>User Email:</strong></td>
                                <td><?php echo e($customer->email); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>User Phone:</strong></td>
                                <td><?php echo e($customer->phone); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Country:</strong></td>
                                <td><?php echo e($customer->country); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Campaign Created:</strong></td>
                                <td><?php echo e(\App\Campaign::where('createdby',$customer->id)->count()); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Joined:</strong></td>
                                <td><?php echo e($customer->created_at->diffForHumans()); ?></td>
                            </tr>
                            <tr>
                                <td width="30%"></td>
                                <td><a href="email/<?php echo e($customer->id); ?>" class="btn btn-primary"><i class="fa fa-send"></i> Contact Customer</a>
                                </td>
                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>