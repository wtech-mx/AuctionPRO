<?php $__env->startSection('content'); ?>

<!-- <?php echo e(url('/assets/images/package')); ?>/<?php echo e($auction->feature_image); ?> -->

    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 4% 0px 4% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($auction->title); ?></h1>
                </div>
            </div>

        </div>
    </section>

    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <div class="col-md-8">

                    <div class="profile-section">
                        <div class="row">

                            <div id="gallery" style="display:none;">

                                <img alt="Image 1 Title" src="<?php echo e(url('/assets/images/auction/'.$auction->feature_image)); ?>"
                                     data-image="<?php echo e(url('/assets/images/auction/'.$auction->feature_image)); ?>"
                                     data-description="Image 1 Description">
                                <?php $__currentLoopData = $gallerys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img alt="Image 2 Title" src="<?php echo e(url('/assets/images/gallery/'.$gallery->image)); ?>"
                                     data-image="<?php echo e(url('/assets/images/gallery/'.$gallery->image)); ?>"
                                     data-description="Image 2 Description">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                        </div>
                    </div>
              
                    <div style="margin-bottom:20px;">
                        <?php if(!empty($ads728x90)): ?>
                        <div class="desktop-advert">
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                    </div>

                    <div class="information-blocks">
                        <div class="card">
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#description" aria-controls="home" role="tab" data-toggle="tab">Description</a></li>
                                <li role="presentation"><a href="#bid-history" aria-controls="profile" role="tab" data-toggle="tab"> Bid History</a></li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="description">
                                    <p><?php echo $auction->description; ?></p>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="bid-history">
                                    <table class="table">
                                        <thead>
                                        <tr class="success">
                                            <th>Bidder</th>
                                            <th>Bid Amount</th>
                                            <th>Date</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($bid->bidder->name); ?></td>
                                                <td>$<?php echo e($bid->bid_amount); ?></td>
                                                <td><?php echo e($bid->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3">No Bid Placed Yet.</td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 contact-info">

                    <?php if(Session::has('pmail')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('pmail')); ?> </div>
                    <?php endif; ?>

                    <div class="col-md-12">
                        
                        <div class="row" style="margin-bottom: 20px;">
                            <div><h4>Created by:<strong class="cby pull-right"><?php echo e($auction->createdby->name); ?></strong></h4></div>
                            <div><h4>Item Condition:<strong class="cby pull-right"><?php echo e($auction->condition); ?></strong></h4></div>
                            <div><h4>Highest Bid:<strong class="cby pull-right"><?php echo e(\App\Bid::maxBid($auction->id)); ?></strong></h4></div>
                            <div><h4>Buy Now:<strong class="cby pull-right">$<?php echo e($auction->price); ?></strong></h4></div>
                        </div>

                            <div class="row">
                                <div>
                                    <h4>
                                        <i class="fa fa-clock-o fa-fw fa-2x"></i>
                                        <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                            <b><?php echo e(0); ?></b>
                                        <?php else: ?>
                                            <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                        <?php endif; ?>
                                        Days Left
                                    </h4>
                                </div>

                                <div>
                                    <h4>
                                        <i class="fa fa-check-circle fa-fw fa-2x"></i>
                                        <?php echo e(\App\Bid::countBid($auction->id)); ?> Bids
                                    </h4>
                                </div>

                            </div>

                            <hr>
                        <div class="row">
                            <div class="profile-group">
                                <!-- AddToAny BEGIN -->
                                <div class="a2a_kit a2a_kit_size_40 a2a_default_style">
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_twitter"></a>
                                    <a class="a2a_button_google_plus"></a>
                                    <a class="a2a_button_linkedin"></a>
                                    <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                                </div>
                                <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <!-- AddToAny END -->
                            </div>
                        </div>

                    <form action="<?php echo e(action('FrontEndController@bid' , ['id'=>$auction->id])); ?>" method="get">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group row" style="margin-bottom: 10px;">
                                <label class="">Bid Amount(USD):</label>
                                <div>
                                    <input type="text" id="donation"  pattern="[0-9]+(\.[0-9]{0,2})?%?"
                                           title="Price must be a numeric or up to 2 decimal places." name="amount" class="form-control costs" value="<?php echo e($auction->default_amount); ?>" required>
                                </div>
                            </div>
                        <div class="col-md-12" style="padding: 0">

                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                            <div class="form-group text-center">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <?php if($auction->status != "open"): ?>
                                        <button type="submit" class="btn btn-ocean btn-block" disabled="disabled"> Place Bid Now</button>
                                    <?php else: ?>
                                        <button type="submit" class="btn btn-ocean btn-block"> Place Bid Now</button>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="col-md-12"><h3 class="text-center">Or</h3></div>

                        </form>

                            <div class="form-group text-center">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <?php if($auction->status != "open"): ?>
                                        <a href="javascript:;"><button type="submit" class="btn btn-ocean btn-block" disabled> Buy Now</button></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/auction/'.$auction->id.'/buy')); ?>"><button type="submit" class="btn btn-ocean btn-block"> Buy Now</button></a>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <div class="row">
                            <div class="col-md-12" style="padding: 0;">
                                <hr>
                                <h3>Recent Bids</h3>
                                <hr>
                                <?php $__empty_1 = true; $__currentLoopData = $recentbids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentbid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="bid-recent">
                                        <span>$ <?php echo e($recentbid->bid_amount); ?></span>
                                        <p><i class="fa fa-check-circle"></i>  <?php echo e($recentbid->bidder->name); ?> - <?php echo e($recentbid->updated_at->diffForHumans()); ?></p>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="bid-recent">
                                        <p>No Bid Placed Yet.</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>


                    </div>

                    <div class="col-md-12 text-center" style="margin-top: 20px;">
                        <?php if(!empty($ads300x250)): ?>
                        <div class="desktop-advert">
                            <?php if($ads300x250->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x250->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x250->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-12">

                    <h3>Related Auctions</h3>

                </div>
            </div>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

    jQuery("#gallery").unitegallery({
        gallery_theme: "compact",
        gallery_autoplay: false,						//true / false - begin slideshow autoplay on start
        gallery_play_interval: 3000,				//play interval of the slideshow
        slider_scale_mode: "fit",
        slider_enable_play_button: false,	//show, hide the theme fullscreen button. The position in the theme is constant
        slider_enable_fullscreen_button: false			//show, hide the theme play button. The position in the theme is constant
    });

    $(".pre").click(function () {
        var val = $(this).val();
        $("#donation").val(val);
    })


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>