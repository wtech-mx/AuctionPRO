<?php $__env->startSection('content'); ?>
    <div id="page-wrapper">
        <div class="container-fluid">

            <div class="row" id="main">

                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('user/campaign/create'); ?>" class="btn btn-primary btn-add"><i class="fa fa-plus"></i> Create New Campaign</a>
                    </div>
                    <h3>My Campaigns</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="res">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(Session::has('error')): ?>
                                <div class="alert alert-danger alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                    <!-- Page Content -->
                            <table class="table table-striped table-bordered" cellspacing="0" id="example" width="100%">
                                <thead>
                                <tr>
                                    <th>Campaign Name</th>
                                    <th>Date</th>
                                    <th>Goal</th>
                                    <th>Funded</th>
                                    <th>Available Fund</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($campaign->title); ?></td>
                                        <td><?php echo e(date('d M',strtotime($campaign->created_at))); ?> - <?php echo e(date('d M',strtotime($campaign->end_date))); ?></td>
                                        <td>$<?php echo e($campaign->goal); ?></td>
                                        <td>$<?php echo e(\App\Donation::getFund($campaign->id)); ?></td>
                                        <td>$<?php echo e($campaign->available_fund); ?></td>
                                        <td><?php echo e(ucfirst($campaign->status)); ?></td>
                                        <td>
                                            <a href="campaign/<?php echo e($campaign->id); ?>" class="btn btn-success btn-xs"><i class="fa fa-eye"></i> View </a>
                                            <a href="campaign/<?php echo e($campaign->id); ?>/edit" class="btn btn-primary btn-xs"><i class="fa fa-edit"></i> Edit </a>
                                            <?php if($campaign->status != "closed"): ?>
                                                <a href="campaign/<?php echo e($campaign->id); ?>/close" class="btn btn-warning btn-xs"><i class="fa fa-toggle-on"></i> Close </a>
                                            <?php else: ?>
                                                <a href="campaign/<?php echo e($campaign->id); ?>/open" class="btn btn-success btn-xs"><i class="fa fa-toggle-off"></i> Open </a>
                                            <?php endif; ?>
                                            <a href="javascript:;" data-href="<?php echo e(url('/')); ?>/user/campaign/<?php echo e($campaign->id); ?>/delete" data-toggle="modal" data-target="#confirm-delete"class="btn btn-danger btn-xs"><i class="fa fa-trash"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

    <div class="modal fade" id="confirm-delete" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content panel-danger">
                <div class="modal-header panel-heading">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h3 class="modal-title" id="myModalLabel"><i class="fa fa-exclamation-circle fa-fw"></i> Confirm Delete</h3>
                </div>
                <div class="modal-body">
                    <p>You are about to delete this Campaign, All Donations will be deleted under this Campaign.</p>
                    <h4>Do you want to proceed?</h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-danger btn-ok">Delete</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <script>
        $('#confirm-delete').on('show.bs.modal', function(e) {
            $(this).find('.btn-ok').attr('href', $(e.relatedTarget).data('href'));
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.master-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>