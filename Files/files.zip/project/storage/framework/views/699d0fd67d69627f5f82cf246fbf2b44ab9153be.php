<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('admin/campaign/pending'); ?>" class="btn btn-default btn-add"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <h3>Campaign Details</h3>
                    
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">

                        <div class="col-xs-12" style="padding: 0">
                            <!-- Tab panes -->

                        <div class="go-title">
                            <h4><?php echo e($campaign->title); ?></h4>
                            <div class="go-line"></div>
                        </div>
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign ID#</strong></td>
                                    <td><?php echo e($campaign->id); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Status:</strong></td>
                                    <td><?php echo e(ucfirst($campaign->status)); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Created On:</strong></td>
                                    <td><?php echo e(date('Y-m-d h:i:sa',strtotime($campaign->created_at))); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Created By:</strong></td>
                                    <td><?php echo e($campaign->createdby->name); ?>,<?php echo e($campaign->createdby->country); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Title:</strong></td>
                                    <td><?php echo e($campaign->title); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Category:</strong></td>
                                    <td><?php echo e($campaign->category); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Feature Image:</strong></td>
                                    <td><img style="max-width: 300px;" src="<?php echo e(url('assets/images/campaign')); ?>/<?php echo e($campaign->feature_image); ?>" ></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Video:</strong></td>
                                    <td><?php echo \App\Campaign::getVideo($campaign->id); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Description:</strong></td>
                                    <td><?php echo $campaign->description; ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Goal:</strong></td>
                                    <td>$<?php echo e($campaign->goal); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign End Date:</strong></td>
                                    <td><?php echo e($campaign->end_date); ?></td>
                                </tr>
                                
                                
                                    
                                    
                                    
                                
                                
                            </tbody>
                        </table>

                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>