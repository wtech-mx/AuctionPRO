<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($pagename); ?></h1>
                </div>
            </div>

        </div>


    </section>


    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <div id="allcamps">
                    <?php $__currentLoopData = $campaigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12 col-sm-6 col-md-4">
                            <div class="package-list wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                                <a href="<?php echo e(url('/')); ?>/campaign/<?php echo e($campaign->id); ?>">
                                    <div class="package-thumb">
                                        <img width="800" height="570" src="<?php echo e(url('/assets/images/campaign')); ?>/<?php echo e($campaign->feature_image); ?>" class="" alt="1">
                                    </div>
                                    <div class="package-info">
                                        <h3><?php echo e($campaign->title); ?></h3>
                                        <div class="row">
                                <span class="pull-left">
                                    <?php if(((strtotime($campaign->end_date)-time())/86400) < 0): ?>
                                        <b><?php echo e(0); ?></b>
                                    <?php else: ?>
                                        <b><?php echo e(ceil((strtotime($campaign->end_date)-time())/86400)); ?></b>
                                    <?php endif; ?>
                                     Days Left
                                </span>
                                            <span class="pull-right">
                                    <b>$<?php echo e(\App\Donation::getFund($campaign->id)); ?></b>
                                     Funded
                                </span>
                                        </div>

                                        <div class="progress">
                                            <div class="progress-bar" role="progressbar" aria-valuenow="<?php echo e(\App\Donation::getPercent($campaign->id)); ?>"
                                                 aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(\App\Donation::getPercent($campaign->id)); ?>%">
                                                <?php echo e(\App\Donation::getPercent($campaign->id)); ?>%
                                            </div>
                                        </div>

                                        <p><?php echo e(substr(strip_tags($campaign->description), 0, 120)); ?>..</p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class='col-md-12 margintop'></div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>