<?php $__env->startSection('content'); ?>

<section style="background: url(<?php echo e(url('/')); ?>/assets/images/background.jpg) no-repeat center center; background-size: cover;">
    <div class="row" style="background-color:rgba(0,0,0,0.7);">
       
            <div style="margin: 4% 0px 4% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($profiledata->name); ?></h1>
                    <p><?php echo e($profiledata->category); ?></p>
                </div>
            </div>
        
    </div>
</section>

<div id="wrapper" class="go-section">
    <div class="row">
        <div class="container">
            <div class="col-md-8">
                <div class="profile-section">
                    <h3 class="no-margin">Profile Description</h3><hr>
                    <?php echo $profiledata->description; ?>}
                </div>
                <div class="profile-section">
                <div class="row">
                    <h3 class="no-margin">Practice Areas</h3><hr>
                        <ul class="col-md-12 specialities">
                            <?php $__currentLoopData = $profiledata->specialities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialitie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="col-md-6 specialitie"><?php echo e($specialitie); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>

                <div class="profile-section">
                <div class="row">
                    <h3 class="no-margin">Qualifications</h3><hr>
                    <ul class="col-md-12 qualifications">
                        <li class="col-md-12 qualification">
                            <strong>Gender</strong>
                            <span><?php echo e($profiledata->gender); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Language</strong>
                            <span><?php echo e($profiledata->qualifications[0]); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Experience</strong>
                            <span><?php echo e($profiledata->qualifications[1]); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Education</strong>
                            <span><?php echo e($profiledata->qualifications[2]); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Residency</strong>
                            <span><?php echo e($profiledata->qualifications[3]); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Professional Experience</strong>
                            <span><?php echo e($profiledata->qualifications[4]); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Certifications</strong>
                            <span><?php echo e($profiledata->qualifications[5]); ?></span>
                        </li>
                        <li class="col-md-12 qualification">
                            <strong>Professional Associations</strong>
                            <span><?php echo e($profiledata->qualifications[6]); ?></span>
                        </li>
                        
                    </ul>
                    </div>
                </div>
                
                <div style="margin-bottom:20px;">
                    <div class="desktop-advert">
                        <?php if($ads728x90[0]->type == "banner"): ?>
                            <a class="ads" href="<?php echo e($ads728x90[0]->redirect_url); ?>" target="_blank">
                                <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90[0]->banner_file); ?>" alt="Advertisement">
                            </a>
                        <?php else: ?>
                            <?php echo $ads728x90[0]->script; ?>

                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-md-12">
                    <h3>Contact Lawyer</h3><hr>
                    <form action="<?php echo e(action('FrontEndController@usermail')); ?>" method="post">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" id="to" name="to" value="shaoneel@gamil.com">
                        <div class="form-group">
                          <label>Name:</label>
                          <input type="text" id="name" name="name" class="form-control" required>
                          <p id="vname" style="color:red;"></p>
                        </div>
                        <div class="form-group">
                          <label>Email:</label>
                          <input type="text" id="email" name="email" class="form-control" required>
                          <p id="vemail" style="color:red;"></p>
                        </div>
                        <div class="form-group">
                          <label>Message:</label>
                          <textarea name="message" rows="8" id="message" class="form-control" required></textarea> 
                          <p id="vmessage" style="color:red;"></p>
                        </div>
                        <div id="load" style="display: none;" class="text-center"><img src="assets/images/loader.gif" style="width: 50px;padding-bottom: 5px; "></div>
                        <div class="form-group" id="submt">
                          <button type="submit" class="btn btn-primary btn-block">Send</button>
                        </div>
                        
                    </form>
                </div>
               
            </div>
            <div class="col-md-4 contact-info">
                <img src="<?php echo e(url('/')); ?>/assets/images/profile_photo/<?php echo e($profiledata->photo); ?>" alt="" style="max-width: 100%;" class="profile-image">
                <div>
                <h3>Contact Info</h3><hr>
                <div class="profile-group">
                     <p class="profile-contact"><i class="fa fa-home fa-1x"></i> <?php echo e($profiledata->address); ?></p>
                     <p class="profile-contact"><i class="fa fa-fax fa-1x"></i> <?php echo e($profiledata->fax); ?></p>
                     <p class="profile-contact"><i class="fa fa-phone fa-1x"></i> <?php echo e($profiledata->phone); ?></p>
                     <p class="profile-contact"><i class="fa fa-envelope fa-1x"></i> <?php echo e($profiledata->email); ?></p>
                     <p class="profile-contact"><i class="fa fa-globe fa-1x"></i> <?php echo e($profiledata->website); ?></p>
                </div>
                     <h3>Share Profile</h3><hr>
                    <div class="profile-group">
                        <!-- AddToAny BEGIN -->
                        <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                        <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                        <a class="a2a_button_facebook"></a>
                        <a class="a2a_button_twitter"></a>
                        <a class="a2a_button_google_plus"></a>
                        <a class="a2a_button_linkedin"></a>
                        </div>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                    </div>
                </div>
                <div class="text-center">
                    <div class="desktop-advert">
                        <?php if($ads300x250[0]->type == "banner"): ?>
                            <a class="ads" href="<?php echo e($ads300x250[0]->redirect_url); ?>" target="_blank">
                                <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250[0]->banner_file); ?>" alt="Advertisement">
                            </a>
                        <?php else: ?>
                            <?php echo $ads300x250[0]->script; ?>

                        <?php endif; ?>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>