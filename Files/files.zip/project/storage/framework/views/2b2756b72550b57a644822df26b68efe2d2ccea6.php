<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, shrink-to-fit=no, initial-scale=1">
    <meta name="keywords" content="<?php echo e($code[0]->meta_keys); ?>">
    <meta name="author" content="GeniusOcean">
    <title><?php echo e($settings[0]->title); ?></title>

    <link rel="icon" 
      type="image/png" 
      href="<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->favicon); ?>">

    <link href="<?php echo e(URL::asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/slicknav.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/owl.carousel.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/magnific-popup.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/style.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/genius-slider.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(URL::asset('assets/css/responsive.css')); ?>" rel="stylesheet">

    <!-- Gallery Css -->
    <link rel='stylesheet' href='<?php echo e(URL::asset('assets/css/unite-gallery.css')); ?>' type='text/css' />
    <link rel='stylesheet' href='<?php echo e(URL::asset('assets/css/ug-theme-default.css')); ?>' type='text/css' />

</head>
<body>
<div id="cover"></div>

<!-- Starting of header area -->
<div class="header-top-area">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-sm-7">
                <div class="top-column-left">
                    <ul>
                        <li>
                            <i class="fa fa-envelope"></i> <?php echo e($settings[0]->email); ?>

                        </li>
                        <?php if($settings[0]->phone != null): ?>
                            <li>
                                <i class="fa fa-phone"></i> <?php echo e($settings[0]->phone); ?>

                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <div class="col-md-6 col-sm-5">
                <div class="top-column-right">
                    <ul class="top-social-links">
                        <li class="top-social-links-li">
                            <?php if($sociallinks[0]->f_status == "enable"): ?>
                                <a href="<?php echo e($sociallinks[0]->facebook); ?>"><i class="fa fa-facebook"></i></a>
                            <?php endif; ?>
                            <?php if($sociallinks[0]->t_status == "enable"): ?>
                                <a href="<?php echo e($sociallinks[0]->twiter); ?>"><i class="fa fa-twitter"></i></a>
                            <?php endif; ?>
                            <?php if($sociallinks[0]->g_status == "enable"): ?>
                                <a href="<?php echo e($sociallinks[0]->g_plus); ?>"><i class="fa fa-google"></i></a>
                            <?php endif; ?>
                            <?php if($sociallinks[0]->link_status == "enable"): ?>
                                <a href="<?php echo e($sociallinks[0]->linkedin); ?>"><i class="fa fa-linkedin"></i></a>
                            <?php endif; ?>
                        </li>
                        <?php if(Auth::guard('profile')->guest()): ?>
                            <li><a href="<?php echo e(url('user/login')); ?>" class="header-buttons"><?php echo e($language->log_in); ?></a></li>
                            <li><a href="<?php echo e(url('user/registration')); ?>" class="header-buttons"><?php echo e($language->sign_up); ?></a></li>
                        <?php else: ?>
                            <li><a href="<?php echo e(url('user/dashboard')); ?>" class="header-buttons"><?php echo e($language->my_account); ?></a></li>
                            <li>
                                <a href="<?php echo e(route('logout')); ?>" class="header-buttons"
                                   onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                    <?php echo e($language->logout); ?>

                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                    <?php echo e(csrf_field()); ?>

                                </form>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="header-area-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-md-2 col-sm-2">
                <div class="logo">
                    <a href="<?php echo e(url('/')); ?>">
                        <img src="<?php echo e(URL::asset('assets/images/logo')); ?>/<?php echo e($settings[0]->logo); ?>" alt="<?php echo e($settings[0]->title); ?>">
                    </a>
                </div>
                <div id="mobile-menu-wrap"></div>
            </div>
            <div class="col-md-10 col-sm-10">
                <div class="mainmenu">
                    <ul id="menuResponsive">
                        <li><a href="<?php echo e(url('/')); ?>" class=""><?php echo e($language->home); ?></a></li>
                        <li><a href="javascript:;"><?php echo e($language->auctions); ?> <span class="caret"></span>
                            </a>
                            <ul>
                                <li><a href="<?php echo e(url('/featured')); ?>" class="">Featured Auctions</a></li>
                                <?php $__currentLoopData = $menucats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><a href="<?php echo e(url('/category/'.$category->slug)); ?>" class=""><?php echo e($category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </li>
                        <?php if($pagesettings[0]->a_status == 1): ?>
                            <li><a href="<?php echo e(url('/about')); ?>" class=""><?php echo e($language->about_us); ?></a></li>
                        <?php endif; ?>
                        <?php if($pagesettings[0]->f_status == 1): ?>
                            <li><a href="<?php echo e(url('/faq')); ?>" class=""><?php echo e($language->faq); ?></a></li>
                        <?php endif; ?>
                        <li><a href="<?php echo e(url('/blog')); ?>" class=""><?php echo e($language->blog); ?></a></li>
                        <?php if($pagesettings[0]->c_status == 1): ?>
                            <li><a href="<?php echo e(url('/contact')); ?>" class=""><?php echo e($language->contact_us); ?></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Ending of header area -->

<?php echo $__env->yieldContent('content'); ?>

<!-- starting of subscribe newsletter area -->
<div class="subscribe-newsletter-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="subscribe-newsletter-area">
                    <div class="row">
                        <div class="col-lg-5 col-md-5 col-sm-6 col-xs-12">
                            <h4><?php echo e($language->subscription); ?></h4>
                            
                        </div>
                        <div class="col-lg-7 col-md-7 col-sm-6 col-xs-12">
                            <form action="<?php echo e(action('FrontEndController@subscribe')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="email" name="email" placeholder="Email Address" required>
                                <button type="submit" class="btn btn-primary"><?php echo e($language->subscribe); ?></button>
                            </form>
                            <p id="resp">
                                <?php if(Session::has('subscribe')): ?>
                                    <?php echo e(Session::get('subscribe')); ?>

                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Ending of subscribe newsletter area -->

<!-- starting of footer area -->
<footer class="section-padding footer-area-wrapper wow fadeInUp">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-area">
                    <div class="footer-title">
                        <div class="footer-title">
                            <?php echo e($language->about_us); ?>

                        </div>
                    </div>
                    <div class="footer-content">
                        <p><?php echo $settings[0]->about; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-area">
                    <div class="footer-title">
                        <?php echo e($language->footer_links); ?>

                    </div>
                    <div class="footer-content">
                        <ul class="about-footer">
                            <li><a href="<?php echo e(url('/')); ?>"><i class="fa fa-caret-right"></i> <?php echo e($language->home); ?></a></li>
                            <li><a href="<?php echo e(url('/about')); ?>"><i class="fa fa-caret-right"></i> <?php echo e($language->about_us); ?></a></li>
                            <li><a href="<?php echo e(url('/faq')); ?>"><i class="fa fa-caret-right"></i> <?php echo e($language->faq); ?></a></li>
                            <li><a href="<?php echo e(url('/contact')); ?>"><i class="fa fa-caret-right"></i> <?php echo e($language->contact_us); ?></a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                <div class="single-footer-area">
                    <div class="footer-title">
                        <?php echo e($language->latest_blogs); ?>

                    </div>
                    <div class="footer-content">
                        <ul class="latest-tweet">
                            <?php $__currentLoopData = $lblogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lblog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="<?php echo e(url('/blog')); ?>/<?php echo e($lblog->id); ?>">
                                        <img src="<?php echo e(url('/assets/images/blog')); ?>/<?php echo e($lblog->featured_image); ?>" alt="">
                                        <span><?php echo e($lblog->title); ?></span>
                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-md-5 col-sm-6 col-xs-12">
                <div class="single-footer-area">
                    <div class="footer-title">
                        <?php echo e($language->contact_us); ?>

                    </div>
                    <div class="footer-content">
                        <div class="contact-info">
                            <p class="contact-info">
                                <i class="fa fa-map-marker" aria-hidden="true"></i>
                                <?php echo e($settings[0]->address); ?>

                            </p>
                            <?php if($settings[0]->phone != null): ?>
                                <p class="contact-info">
                                    <i class="fa fa-phone" aria-hidden="true"></i>
                                    <a href="tel:<?php echo e($settings[0]->phone); ?>"><?php echo e($settings[0]->phone); ?></a><br/>
                                </p>
                            <?php endif; ?>
                            <?php if($settings[0]->fax != null): ?>
                                <p class="contact-info">
                                    <i class="fa fa-fax" aria-hidden="true"></i>
                                    <a href="tel:<?php echo e($settings[0]->fax); ?>"><?php echo e($settings[0]->fax); ?></a><br/>
                                </p>
                            <?php endif; ?>
                            <p class="contact-info">
                                <i class="fa fa-envelope" aria-hidden="true"></i>
                                <a href="mailto:<?php echo e($settings[0]->email); ?>"><?php echo e($settings[0]->email); ?></a>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <hr/>
    <div class="footer-copyright-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <p class="copy-right-side">
                        <?php echo $settings[0]->footer; ?>

                    </p>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6">
                    <div class="footer-social-links">
                        <ul>
                            <?php if($sociallinks[0]->f_status == "enable"): ?>
                                <li>
                                    <a class="facebook" href="<?php echo e($sociallinks[0]->facebook); ?>">
                                        <i class="fa fa-facebook"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if($sociallinks[0]->g_status == "enable"): ?>
                                <li>
                                    <a class="google" href="<?php echo e($sociallinks[0]->g_plus); ?>">
                                        <i class="fa fa-google"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if($sociallinks[0]->t_status == "enable"): ?>
                                <li>
                                    <a class="twitter" href="<?php echo e($sociallinks[0]->twiter); ?>">
                                        <i class="fa fa-twitter"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                            <?php if($sociallinks[0]->link_status == "enable"): ?>
                                <li>
                                    <a class="tumblr" href="<?php echo e($sociallinks[0]->linkedin); ?>">
                                        <i class="fa fa-linkedin"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<!-- Ending of footer area -->


    <script src="<?php echo e(URL::asset('assets/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/wow.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.counterup.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/jquery.slicknav.min.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/main.js')); ?>"></script>
    <script src="<?php echo e(URL::asset('assets/js/genius-slider.js')); ?>"></script>

    <script type='text/javascript' src='<?php echo e(URL::asset('assets/js/unitegallery.min.js')); ?>'></script>
    <script type='text/javascript' src='<?php echo e(URL::asset('assets/js/ug-theme-compact.js')); ?>'></script>
    <?php echo $code[0]->google_analytics; ?>

    <?php echo $__env->yieldContent('footer'); ?>

    <script>

        $(window).load(function(){
            setTimeout(function(){
            $('#cover').fadeOut(1000);
            },1000)
        });

    </script>
</body>
</html>