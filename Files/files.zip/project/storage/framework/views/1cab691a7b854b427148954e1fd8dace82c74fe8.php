<?php $__env->startSection('content'); ?>

    <?php if($pagesettings[0]->slider_status): ?>
    <!-- Starting of Slider area -->
    <div id="bootstrap-touch-slider" class="carousel bs-slider fade  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000">

        <!-- Indicators -->
    
    
    
    
    
    
    
    
    

    <!-- Wrapper For Slides -->
        <div class="carousel-inner" role="listbox">

        <?php for($i = 0; $i < count($sliders); $i++): ?>
            <?php if($i == 0): ?>
                <!-- Third Slide -->
                    <div class="item active">

                        <!-- Slide Background -->
                        <img src="<?php echo e(url('/')); ?>/assets/images/sliders/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                        <div class="bs-slider-overlay"></div>

                        <div class="container">
                            <div class="row">
                                <!-- Slide Text Layer -->
                                <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">

                                    <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                                    <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- End of Slide -->
            <?php else: ?>
                <!-- Second Slide -->
                    <div class="item">

                        <!-- Slide Background -->
                        <img src="<?php echo e(url('/')); ?>/assets/images/sliders/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                        <div class="bs-slider-overlay"></div>
                        <!-- Slide Text Layer -->
                        <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">
                            <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                            <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>
                        </div>
                    </div>
                    <!-- End of Slide -->
                <?php endif; ?>
            <?php endfor; ?>


        </div><!-- End of Wrapper For Slides -->

        <!-- Left Control -->
        <a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev">
            <span class="fa fa-angle-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <!-- Right Control -->
        <a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next">
            <span class="fa fa-angle-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div>
    <!-- Ending of Slider area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->split_status): ?>
    <!-- Starting of service area -->
    <div class="section-padding charity-service-area-wrapper">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $splits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $split): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                        <div class="single-charity-service-area">
                            <i class="fa <?php echo e($split->icon); ?>"></i>
                            <h3><?php echo e($split->title); ?></h3>
                            <p><?php echo $split->text; ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Ending of service area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->welcome_status): ?>
        <!-- Starting of help fund area -->
        <div class="section-padding helping-fund-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <img src="<?php echo e(url('/assets/images/')); ?>/<?php echo e($pagesettings[0]->welcome_image); ?>" alt="">
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                        <h1><?php echo e($pagesettings[0]->welcome_title); ?></h1>
                        <p><?php echo e($pagesettings[0]->welcome_description); ?></p>
                        <?php if($pagesettings[0]->w_b_status == 1): ?>
                            <a href="<?php echo e($pagesettings[0]->welcome_link); ?>" class="boxed-btn"><?php echo e($language->view_details); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of help fund area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->service_status): ?>
        <!-- Starting of service area -->
        <div class="section-padding service-area-wrapper overlay wow fadeInUp" style="background-image: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-title text-center">
                            <h2><?php echo e($languages->service_title); ?></h2>
                            <p><?php echo e($languages->service_text); ?></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6">
                            <div class="single-service-box">
                                <div class="service-icon">
                                    <img src="<?php echo e(url('/assets/images/service')); ?>/<?php echo e($service->icon); ?>" alt="Service Image">
                                </div>
                                <div class="service-text">
                                    <h3><?php echo e($service->title); ?></h3>
                                    <p><?php echo e($service->text); ?></p>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- Ending of service area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->category_status): ?>
        <!-- Starting of Campaign Categories area -->
        <div class="section-padding campaign-categories-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-title text-center">
                            <h2><?php echo e($languages->category_title); ?></h2>
                            <p><?php echo e($languages->category_text); ?></p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                            <div class="single-campaignCategories-area">
                                <img src="<?php echo e(url('/assets/images/category')); ?>/<?php echo e($category->image); ?>" alt="">
                                <a href="category/<?php echo e($category->slug); ?>" class="single-campaignCategories-header">
                                    <h3><?php echo e($category->name); ?></h3>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- Ending of Campaign Categories area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->featured_status): ?>
    <!-- Starting of Featured Auction area -->
    <div class="section-padding featured-auction-wrapper wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-title text-center">
                        <h2><?php echo e($languages->pricing_title); ?></h2>
                        <p><?php echo e($languages->pricing_text); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel featured-list">
                        <?php $__currentLoopData = $fauctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/')); ?>/auction/<?php echo e($auction->id); ?>" class="single-featured-item">
                            <div class="featured-img">
                                <img class="featured-img" src="<?php echo e(url('/assets/images/auction')); ?>/<?php echo e($auction->feature_image); ?>" alt="">
                            </div>

                            <div class="featured-text">
                                <div class="featured-meta">
                                    <span class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e($auction->price); ?></span>
                                    <span><?php echo e($language->highest_bid); ?>  <strong class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Bid::maxBid($auction->id)); ?></strong></span>
                                </div>
                                <h4><?php echo e($auction->title); ?></h4>
                                <ul>
                                    <li><span><?php echo e(\App\Bid::countBid($auction->id)); ?></span> <?php echo e($language->bids); ?></li>
                                    <li><span><?php echo e($auction->condition); ?></span> <?php echo e($language->conditions); ?></li>
                                    <li><span>
                                            <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                                <b><?php echo e(0); ?></b>
                                            <?php else: ?>
                                                <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                            <?php endif; ?>
                                        </span>
                                        <?php echo e($language->days_left); ?>

                                    </li>
                                </ul>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Ending of Featured Auction area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->latest_status): ?>
    <!-- Starting of Latest Auction area -->
    <div class="section-padding blog-area-wrapper padding-top-0 wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-title text-center">
                        <h2><?php echo e($languages->newcamp_title); ?></h2>
                        <p><?php echo e($languages->newcamp_text); ?></p>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="owl-carousel blog-area-slider">
                        <?php $__currentLoopData = $newauctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(url('/')); ?>/auction/<?php echo e($auction->id); ?>" class="single-featured-item">
                                <div class="featured-img">
                                    <img class="featured-img" src="<?php echo e(url('/assets/images/auction')); ?>/<?php echo e($auction->feature_image); ?>" alt="">
                                </div>

                                <div class="featured-text">
                                    <div class="featured-meta">
                                        <span class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e($auction->price); ?></span>
                                        <span><?php echo e($language->highest_bid); ?>  <strong class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Bid::maxBid($auction->id)); ?></strong></span>
                                    </div>
                                    <h4><?php echo e($auction->title); ?></h4>
                                    <ul>
                                        <li><span><?php echo e(\App\Bid::countBid($auction->id)); ?></span> <?php echo e($language->bids); ?></li>
                                        <li><span><?php echo e($auction->condition); ?></span> <?php echo e($language->conditions); ?></li>
                                        <li><span>
                                            <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                                    <b><?php echo e(0); ?></b>
                                                <?php else: ?>
                                                    <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                                <?php endif; ?>
                                        </span>
                                            <?php echo e($language->days_left); ?>

                                        </li>
                                    </ul>
                                </div>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Ending of Latest Auction area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->counter_status): ?>
    <!-- Starting of counterUp area -->
    <div class="section-padding counter-up-section overlay text-center wow fadeInUp" style="background-image: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>);">
        <div class="container">
            <div class="row">
                <div class="conuter-up-textArea">
                    <div class="col-md-4 col-sm-4">
                        <div class="single-counter-box">
                            <h2 class="counter-number"><?php echo e(\App\Auction::where('status','open')->count()); ?></h2>
                            <p><?php echo e($language->running_auctions); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="single-counter-box">
                            <h2 class="counter-number"><?php echo e(\App\Bid::count()); ?></h2>
                            <p><?php echo e($language->total); ?> <?php echo e($language->bids); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-4">
                        <div class="single-counter-box">
                            <h2 class="counter-number"><?php echo e(\App\Auction::where('status','closed')->count()); ?></h2>
                            <p><?php echo e($language->completed_auctions); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Ending of counterUp area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->portfolio_status): ?>
        <!-- Starting of Gallery area -->
        <div class="section-padding gallery-area-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-title text-center">
                            <h2><?php echo e($languages->portfolio_title); ?></h2>
                            <p><?php echo e($languages->portfolio_text); ?></p>
                        </div>
                    </div>
                </div>
                <div class="row gallery-list">
                    <?php $__currentLoopData = $portfilos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfilo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="single-gallery-item">
                                <img src="<?php echo e(url('/assets/images/portfolio')); ?>/<?php echo e($portfilo->image); ?>" alt="Gallery image">
                                <div class="gallery-overlay"></div>
                                <div class="gallery-icons">
                                    <a class="image-popup" href="<?php echo e(url('/assets/images/portfolio')); ?>/<?php echo e($portfilo->image); ?>">
                                        <i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <!-- Ending of Gallery area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->testimonial_status): ?>
        <!-- Starting of carousel testimonial area -->
        <div class="section-padding home-testimonial-wrapper overlay wow fadeInUp" style="background-image: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>);">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-title text-center">
                            <h2><?php echo e($languages->testimonial_title); ?></h2>
                            <p><?php echo e($languages->testimonial_text); ?></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-8 col-sm-offset-2">
                        <div class="owl-carousel testimonial-section animated fadeInRight">
                            <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-testimonial-area">
                                    <div class="testimonial-text">
                                        <p class="ctext"><?php echo e($testimonial->review); ?></p>
                                    </div>
                                    <div class="testimonial-author">
                                        <img src="<?php echo e(url('/assets/images')); ?>/testimonial-author-1.png" alt="Author">
                                        <h4><strong><?php echo e($testimonial->client); ?></strong> <br> <?php echo e($testimonial->designation); ?></h4>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of carousel testimonial area -->
    <?php endif; ?>

    <?php if($pagesettings[0]->blog_status): ?>
        <!-- Starting of blog area -->
        <div class="section-padding blog-area-wrapper wow fadeInUp">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="section-title text-center">
                            <h2><?php echo e($languages->blog_title); ?></h2>
                            <p><?php echo e($languages->blog_text); ?></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="blog-area-slider">
                            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <a href="<?php echo e(url('/blog')); ?>/<?php echo e($blog->id); ?>" class="single-blog-box">
                                    <div class="blog-thumb-wrapper">
                                        <img src="<?php echo e(url('/assets/images/blog')); ?>/<?php echo e($blog->featured_image); ?>" alt="Blog Image">
                                    </div>
                                    <div class="blog-text">
                                        <p class="blog-meta"><?php echo e(date('d M Y',strtotime($blog->created_at))); ?></p>
                                        <h4><?php echo e($blog->title); ?></h4>
                                        <p class="blog-meta-text"><?php echo e(substr(strip_tags($blog->details),0,125)); ?></p>
                                        <span class="boxed-btn"><?php echo e($language->view_details); ?></span>
                                    </div>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Ending of blog area -->
    <?php endif; ?>


    <?php if($pagesettings[0]->home_reg_status): ?>
    <!-- Starting of Volunteer registration area -->
    <div class="section-padding volunteer-registration-wrapper wow fadeInUp">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <img src="<?php echo e(url('/')); ?>/assets/images/850117_people_512x512.png" alt="">
                </div>
                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                    <div class="panel panel-default volunteer-registration">
                        <div class="panel-heading"><?php echo e($language->sign_up); ?></div>
                        <div class="panel-body">
                            <form action="<?php echo e(route('user.reg.submit')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form-group">
                                    <input type="text" name="name" class="form-control" placeholder="Full Name">
                                </div>
                                <div class="form-group">
                                    <input type="text" name="phone" class="form-control" placeholder="Phone Number">
                                </div>
                                <div class="form-group">
                                    <input type="email" name="email" class="form-control" placeholder="Email">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password" class="form-control" placeholder="Password">
                                </div>
                                <div class="form-group">
                                    <input type="password" name="password_confirmation" class="form-control" placeholder="Confirm Password">
                                </div>
                                <div id="resp">
                                    <?php if($errors->has('name')): ?>
                                        <span class="help-block">
                                        <strong>* <?php echo e($errors->first('name')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    <?php if($errors->has('email')): ?>
                                        <span class="help-block">
                                        <strong>* <?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                    <?php endif; ?>
                                    <?php if($errors->has('password')): ?>
                                        <span class="help-block">
                                    <strong>* <?php echo e($errors->first('password')); ?></strong>
                                </span>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group text-center">
                                    <button type="submit" class="btn boxed-btn register"><?php echo e($language->sign_up); ?></button>
                                </div>
                                <div class="form-group text-center">
                                    <a href="<?php echo e(route('user.login')); ?>">Already have an account? Login</a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Ending of Volunteer registration area -->
    <?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>