<?php $__env->startSection('content'); ?>

    <section class="go-section">
        <div class="row">
            <div class="container">
                <h2 class="text-center"><?php echo e($pagename); ?></h2>
                <hr>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 text-center services">
                    <div class="single-box">
                        <h1><?php echo e($service->cost); ?>$</h1>
                        <p><?php echo $service->details; ?></p>

                        <a href="<?php echo e(url('/services/order')); ?>/<?php echo e($service->id); ?>" class="genius-btn">
                            Order Now
                        </a>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>