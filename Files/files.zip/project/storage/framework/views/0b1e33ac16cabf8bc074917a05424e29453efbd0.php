<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('user/campaign'); ?>" class="btn btn-default btn-add"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <h3>Campaign Details</h3>
                    
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="col-md-12">
                            <ul class="nav nav-tabs tabs-left">
                                <li class="active"><a href="#campdetails" data-toggle="tab" aria-expanded="false"><strong>Campaign Details</strong></a>
                                <li><a href="#donations" data-toggle="tab" aria-expanded="true"><strong>Donations</strong></a>
                                <li><a href="#withdraws" data-toggle="tab" aria-expanded="true"><strong>Withdraws</strong></a>
                                </li>
                            </ul>
                        </div>

                        <div class="col-xs-12" style="padding: 0">
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div class="tab-pane active" id="campdetails">
                                    <div class="go-title">
                                        <h4><?php echo e($campaign->title); ?> (<a href="<?php echo e($campaign->id); ?>/edit">Edit</a>)</h4>
                                        <div class="go-line"></div>
                                    </div>
                        <table class="table">
                            <tbody>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign ID#</strong></td>
                                    <td><?php echo e($campaign->id); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Status:</strong></td>
                                    <td><?php echo e(ucfirst($campaign->status)); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Created On:</strong></td>
                                    <td><?php echo e(date('Y-m-d h:i:sa',strtotime($campaign->created_at))); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Created By:</strong></td>
                                    <td><?php echo e($campaign->createdby->name); ?>,<?php echo e($campaign->createdby->country); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Title:</strong></td>
                                    <td><?php echo e($campaign->title); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Category:</strong></td>
                                    <td><?php echo e($campaign->category); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Feature Image:</strong></td>
                                    <td><img style="max-width: 300px;" src="<?php echo e(url('assets/images/campaign')); ?>/<?php echo e($campaign->feature_image); ?>" ></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Video:</strong></td>
                                    <td><?php echo \App\Campaign::getVideo($campaign->id); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Description:</strong></td>
                                    <td><?php echo $campaign->description; ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign Goal:</strong></td>
                                    <td>$<?php echo e($campaign->goal); ?></td>
                                </tr>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong>Campaign End Date:</strong></td>
                                    <td><?php echo e($campaign->end_date); ?></td>
                                </tr>
                            </tbody>
                        </table>

                        </div>
                        <div class="tab-pane" id="donations">
                            <div class="go-title">
                                <h4>Total Fund Received: <strong>$<?php echo e(\App\Donation::getFund($campaign->id)); ?></strong></h4>
                                <h4>Total Donations: <strong><?php echo e(\App\Donation::getDonations($campaign->id)); ?></strong></h4>
                                <div class="go-line"></div>
                            </div>
                            <div class="col-md-12">

                            <table class="table table-striped">
                                <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Donation Amount</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = \App\Campaign::campDonations($campaign->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $donation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($donation->donator_name); ?></td>
                                    <td><?php echo e($donation->donator_email); ?></td>
                                    <td>$<?php echo e($donation->amount); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3">No Donations Yet.</td>
                                </tr>
                                <?php endif; ?>
                                </tbody>
                            </table>
                            </div>
                        </div>
                        <div class="tab-pane" id="withdraws">
                            <div class="go-title">
                                <h4>Total Withdrawals Made: $<?php echo e(\App\Withdraw::campWithdraw($campaign->id)); ?></h4>
                                <?php if(\App\Withdraw::pendWithdraw($campaign->id) > 0): ?>
                                    <h5>Withdraw Pending: $<?php echo e(\App\Withdraw::pendWithdraw($campaign->id)); ?></h5>
                                <?php endif; ?>
                                <h4>Available Fund: $<?php echo e($campaign->available_fund); ?></h4>
                                <a href="<?php echo e(url('user/campaign/'.$campaign->id.'/withdraw')); ?>" class="btn btn-primary btn-xs">Withdraw Now</a>
                                <div class="go-line"></div>
                            </div>
                            <div class="col-md-12">

                                <table class="table table-striped">
                                    <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Withdraw Method</th>
                                        <th>Account</th>
                                        <th>Withdraw Amount</th>
                                        <th>Charge</th>
                                        <th>Status</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = \App\Campaign::campWithdraws($campaign->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td><?php echo e($withdraw->created_at); ?></td>
                                            <td><?php echo e($withdraw->method); ?></td>
                                            <?php if($withdraw->method != "Bank"): ?>
                                                <td><?php echo e($withdraw->acc_email); ?></td>
                                            <?php else: ?>
                                                <td><?php echo e($withdraw->iban); ?></td>
                                            <?php endif; ?>
                                            <td>$<?php echo e($withdraw->amount); ?></td>
                                            <td>$<?php echo e($withdraw->fee); ?></td>
                                            <td><label class="label label-default"><?php echo e(ucfirst($withdraw->status)); ?></label></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="3">No Withdrawals Made.</td>
                                        </tr>
                                    <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.master-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>