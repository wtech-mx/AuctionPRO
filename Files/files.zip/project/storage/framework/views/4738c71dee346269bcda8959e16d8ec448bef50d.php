<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($pagename); ?></h1>
                </div>
            </div>

        </div>
    </section>



    <!-- Starting of Featured Auction area -->
    <div class="section-padding all-blogs-area-wrapper wow fadeInUp">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <a href="<?php echo e(url('/')); ?>/auction/<?php echo e($auction->id); ?>" class="single-featured-item">
                            <div class="featured-img">
                                <img class="featured-img" src="<?php echo e(url('/assets/images/auction')); ?>/<?php echo e($auction->feature_image); ?>" alt="">
                            </div>

                            <div class="featured-text">
                                <div class="featured-meta">
                                    <span class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e($auction->price); ?></span>
                                    <span><?php echo e($language->highest_bid); ?>  <strong class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Bid::maxBid($auction->id)); ?></strong></span>
                                </div>
                                <h4><?php echo e($auction->title); ?></h4>
                                <ul>
                                    <li><span><?php echo e(\App\Bid::countBid($auction->id)); ?></span> <?php echo e($language->bids); ?></li>
                                    <li><span><?php echo e($auction->condition); ?></span> <?php echo e($language->conditions); ?></li>
                                    <li><span>
                                            <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                                <b><?php echo e(0); ?></b>
                                            <?php else: ?>
                                                <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                            <?php endif; ?>
                                        </span>
                                        <?php echo e($language->days_left); ?>

                                    </li>
                                </ul>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Ending of Featured Auction area -->



    
        
            
                
                    
                        
                            
                                
                                    
                                        
                                    
                                    

                                        
                                        
                                        

                                        
                                            
                                                
                                                
                                            
                                            
                                                
                                                
                                            
                                            
                                                
                                                    
                                                
                                                    
                                                
                                                
                                            

                                        
                                    
                                
                            
                        
                    
                        
                            
                        
                    
                    
                

            
        
    

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>