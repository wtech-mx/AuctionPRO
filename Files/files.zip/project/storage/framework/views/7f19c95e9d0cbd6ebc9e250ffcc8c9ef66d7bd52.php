<?php $__env->startSection('content'); ?>



    <section style="background: url(http://localhost/model/assets/images/background.jpg) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 4% 0px 4% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($package->title); ?></h1>
                </div>
            </div>

        </div>
    </section>

    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <div class="col-md-8">

                    <div class="profile-section">
                        <div class="row">
                            
                                
                            
                            <div class="profile-group pull-right">
                                <!-- AddToAny BEGIN -->
                                <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                                    <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_twitter"></a>
                                    <a class="a2a_button_google_plus"></a>
                                    <a class="a2a_button_linkedin"></a>
                                </div>
                                <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <!-- AddToAny END -->
                            </div>
                        </div>

                        <div id="gallery" style="display:none;">
                            <?php $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img alt=""
                                     src="<?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($images->image); ?>"
                                     data-image="<?php echo e(url('/assets/images/gallery')); ?>/<?php echo e($images->image); ?>"
                                     data-description="">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>
                    <div class="profile-section">
                        <div class="row" style="margin-top: 10px;">
                            <div class="col-md-4"><strong>DEPARTURE DATE</strong></div>
                            <div class="col-md-8 col-sm-12 col-xs-12" style="padding-left: 0">
                                <div class="specialities pull-right">
                                    <span><?php echo e(date('Y-m-d',strtotime($package->start_date))); ?></span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4"><strong>RETURN DATE</strong></div>
                            <div class="col-md-8 col-sm-12 col-xs-12" style="padding-left: 0">
                                <div class="specialities pull-right">
                                    <span><?php echo e(date('Y-m-d',strtotime($package->return_date))); ?></span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4"><strong>DEPARTURE LOCATION</strong></div>
                            <div class="col-md-8 col-sm-12 col-xs-12" style="padding-left: 0">
                                <div class="specialities pull-right">
                                    <span><?php echo e($package->departure_location); ?></span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4"><strong>INCLUDED</strong></div>
                            <div class="col-md-8 col-sm-12 col-xs-12" style="padding-left: 0">
                                <div class="specialities pull-right">
                                    <?php $__currentLoopData = $package->includes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $include): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="col-md-6 included"><i class="fa fa-check"></i> <?php echo e($include); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4"><strong>EXCLUDED</strong></div>
                            <div class="col-md-8 col-sm-12 col-xs-12" style="padding-left: 0">
                                <div class="specialities pull-right">
                                    <?php $__currentLoopData = $package->excludes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exclude): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p class="col-md-6 excluded"><i class="fa fa-times"></i> <?php echo e($exclude); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <hr>
                            <div class="col-md-12">
                            <h3 class="no-margin">Package Details</h3><hr>
                            <p><?php echo $package->description; ?></p>
                        </div>
                        </div>
                        
                        
                    </div>

                    <div style="margin-bottom:20px;">
                        <?php if(!empty($ads728x90)): ?>
                        <div class="desktop-advert">
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
                <div class="col-md-4 contact-info">

                    <?php if(Session::has('pmail')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('pmail')); ?> </div>
                    <?php endif; ?>

                    <div class="col-md-12">
                        <h3 class="text-center">Book The Tour</h3><hr>

            <form action="<?php echo e(action('FrontEndController@order' , ['id'=>$package->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <!-- <div class="form-group">
                                <input type="text" placeholder="Name" name="name" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <input type="text" placeholder="Email" name="email" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <input type="text" placeholder="Phone" name="phone" class="form-control" required>
                            </div>
 -->
                            <div class="form-group row">
                                <label class="control-label col-md-3" style="margin-top: 8px;padding: 0;">Adults</label>
                                <div class="col-md-4" style="padding-left: 0;margin-bottom: 8px;">
                                    <input type="number" step=1 name="adults" oninput="cacl()" id="adult" class="form-control costs" value="0" required>
                                </div>
                                <span class="control-label col-md-3" style="margin-top: 8px;padding: 0;">x $<?php echo e($package->cost_adult); ?></span>

                            </div>
                            <div class="form-group row">
                                <label class="col-md-3" style="margin-top: 8px;padding: 0;">Children</label>
                                <div class="col-md-4" style="padding-left: 0;">
                                    <input type="number" step=1 id="child" oninput="cacl()" name="childs" class="form-control costs" value="0" required>
                                </div>
                                <span class="control-label col-md-3" style="margin-top: 8px;padding: 0;">x $<?php echo e($package->cost_child); ?></span>

                            </div>
                            <div class="col-md-12" style="padding: 10px 0px;">Total: <span id="ttl">0</span>$</div>
                            <input type="hidden" name="total" id="totals" value="0" />
                            
                            <div class="form-group text-center">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-ocean btn-block"><i class="fa fa-paypal fa-fw"></i> Book Now</button>
                                </div>
                            </div>

                        </form>
                    </div>

                    <div class="col-md-12">
                        <hr><h3 class="text-center">OR</h3><hr>
                        <form action="<?php echo e(action('FrontEndController@usermail')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" id="to" name="pid" value="<?php echo e($package->id); ?>">
                            <div class="form-group">
                                <label>Name:</label>
                                <input type="text" id="name" name="name" class="form-control" required>
                                <p id="vname" style="color:red;"></p>
                            </div>
                            <div class="form-group">
                                <label>Email:</label>
                                <input type="text" id="email" name="email" class="form-control" required>
                                <p id="vemail" style="color:red;"></p>
                            </div>
                            <div class="form-group">
                                <label>Message:</label>
                                <textarea name="message" rows="8" id="message" class="form-control" required></textarea>
                                <p id="vmessage" style="color:red;"></p>
                            </div>
                            <div id="load" style="display: none;" class="text-center"><img src="assets/images/loader.gif" style="width: 50px;padding-bottom: 5px; "></div>
                            <div class="form-group text-center" id="submt">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-ocean btn-block">Send Query</button>
                                </div>
                            </div>

                        </form>
                    </div>

                    <div class="col-md-12 text-center" style="margin-top: 20px;">
                        <?php if(!empty($ads300x250)): ?>
                        <div class="desktop-advert">
                            <?php if($ads300x250->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x250->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x250->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    function cacl() {
        var adult = parseFloat(<?php echo e($package->cost_adult); ?>);
        var child = parseFloat(<?php echo e($package->cost_child); ?>);
        var ttl = $("#adult").val() * adult;
        var ttls = ttl + $("#child").val() * child;
        $('#ttl').html(ttls);
        $('#totals').val(ttls);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>