<?php $__env->startSection('content'); ?>



    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row">
            <div class="container" style="min-height: 300px;">
                <div class="home-section">
                    <h1>WORLD CLASS</h1>
                    <p>SOCIAL MEDIA PROMOTION</p>

                    <button class="btn btn-home">Facebook</button>
                    <button class="btn btn-home">Facebook</button>
                    <button class="btn btn-home">Facebook</button>
                    <button class="btn btn-home">Facebook</button>
                </div>
            </div>
        </div>
    </section>

    <section class="go-section">
        <div class="row">
            <div class="container">
                <h2 class="text-center">All Available Services</h2>
                <hr>

                <div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1>Facebook</h1>
                        <p>Services</p>
                        <button class="btn btn-views">View</button>
                    </div>
                </div>
                <div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1>Facebook</h1>
                        <p>Services</p>
                        <button class="btn btn-views">View</button>
                    </div>
                </div>
                <div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1>Facebook</h1>
                        <p>Services</p>
                        <button class="btn btn-views">View</button>
                    </div>
                </div>
<div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1>Facebook</h1>
                        <p>Services</p>
                        <button class="btn btn-views">View</button>
                    </div>
                </div>
<div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1>Facebook</h1>
                        <p>Services</p>
                        <button class="btn btn-views">View</button>
                    </div>
                </div>
<div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1>Facebook</h1>
                        <p>Services</p>
                        <button class="btn btn-views">View</button>
                    </div>
                </div>

            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>