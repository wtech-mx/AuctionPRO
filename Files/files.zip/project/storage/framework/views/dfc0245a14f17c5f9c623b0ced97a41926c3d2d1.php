<?php $__env->startSection('content'); ?>


    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard subscribers data-table area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header products">
                                        <h2>My Bids</h2>
                                    </div>
                                    <hr/>
                                    <div class="table-responsive">
                                        <div id="response" class="col-md-12">
                                            <?php if(Session::has('message')): ?>
                                                <div class="alert alert-success alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                    <?php echo e(Session::get('message')); ?>

                                                </div>
                                            <?php endif; ?>
                                            <?php if(Session::has('error')): ?>
                                                <div class="alert alert-danger alert-dismissable">
                                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                    <?php echo e(Session::get('error')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <table id="product-table_wrapper" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                            <thead>
                                            <tr>
                                                <th>Date</th>
                                                <th>Auction</th>
                                                <th>Bid Amount</th>
                                                <th>Actions</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <?php $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($bid->created_at); ?></td>
                                                    <td><?php echo e($bid->auctionid->title); ?></td>
                                                    <td>$<?php echo e($bid->bid_amount); ?></td>
                                                    <td>
                                                        <?php if($bid->auctionid->status != "open"): ?>
                                                            <?php if($bid->winner == "yes"): ?>
                                                                <strong>(Winner)</strong>
                                                                <?php if(\App\Auction::findOrFail($bid->auctionid->id)->paid_status == "no"): ?>
                                                                    <a href="<?php echo e(url('user/winner/'.$bid->id.'/pay')); ?>" class="btn btn-primary product-btn">Pay Now</a>
                                                                <?php else: ?>
                                                                    <label class="label label-success">Paid</label>
                                                                <?php endif; ?>
                                                            <?php else: ?>
                                                                Auction Completed
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <a href="mybids/<?php echo e($bid->id); ?>/edit" class="btn btn-primary product-btn"><i class="fa fa-edit"></i> Edit </a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    </div>
                                    <hr/>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard subscribers data-table area -->

                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.masterpage-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>