

<?php $__env->startSection('content'); ?>

<div id="wrapper" class="go-section">
    <div class="row">
        <div class="container">
            <div class="container">
                <!-- Form Name -->
                <h2 class="text-center marginbottom">Login</h2>

                <form role="form" method="POST" action="<?php echo e(route('user.login.submit')); ?>">
                    <?php echo e(csrf_field()); ?>

                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="form-group">
                                <input name="email" value="<?php echo e(old('email')); ?>" placeholder="Email" class="form-control" type="email" required>
                                <p id="emailError" class="errorMsg"></p>
                            </div>
                        </div>
                    </div>
                    <!-- Text input-->
                    <div class="row">
                        <div class="col-md-6 col-md-offset-3">
                            <div class="form-group">
                                <input name="password" placeholder="Password" class="form-control"  type="password" required>
                                <p id="passError" class="errorMsg"></p>
                            </div>
                        </div>
                    </div>

                    <div id="resp" class="col-md-6 col-md-offset-3">
                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                        <?php endif; ?>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                                    <strong><?php echo e($errors->first('email')); ?></strong>
                                </span>
                        <?php endif; ?>
                        <?php if(Session::has('error')): ?>
                            <div class="alert alert-danger alert-dismissable">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo e(Session::get('error')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    <!-- Button -->
                    <div class="row text-center">
                        <div class="col-md-6 col-md-offset-3 login">
                        <div class="col-md-4 marginbottom">
                            <a href="<?php echo e(route('user.reg')); ?>" class="text-center">Create a New Account.</a>
                        </div>
                        <div class="col-md-4">
                            <button type="submit" class="btn btn-ocean" id="LoginButton"><strong>Login</strong></button>
                        </div>
                        <div class="col-md-4">
                            <a href="<?php echo e(route('user.forgotpass')); ?>">Forgot Password?</a>
                        </div>

                        </div>
                    </div>

                    <div class="form-group text-center">

                    </div>

                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>