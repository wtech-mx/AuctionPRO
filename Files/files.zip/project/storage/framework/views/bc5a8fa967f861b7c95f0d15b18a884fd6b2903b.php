<?php $__env->startSection('content'); ?>

    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="margin:0;background-color:rgba(0,0,0,0.7);">
            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($language->blog); ?></h1>
                </div>
            </div>
        </div>
    </section>


    <!-- Starting of All blogs area -->
    <div class="section-padding all-blogs-area-wrapper wow fadeInUp">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                    <a href="<?php echo e(url('/')); ?>/blog/<?php echo e($blog->id); ?>" class="single-all-blogs-box">
                        <div class="blog-thumb-wrapper">
                            <img src="<?php echo e(url('/')); ?>/assets/images/blog/<?php echo e($blog->featured_image); ?>" alt="Blog Image">
                        </div>
                        <div class="blog-text">
                            <p class="blog-meta"><?php echo e(date('d M Y',strtotime($blog->created_at))); ?></p>
                            <h4><?php echo e($blog->title); ?></h4>
                            <p class="blog-meta-text"><?php echo e(substr(strip_tags($blog->details),0,125)); ?></p>
                            <span class="boxed-btn"><?php echo e($language->view_details); ?></span>
                        </div>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- Ending of All blogs area -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>