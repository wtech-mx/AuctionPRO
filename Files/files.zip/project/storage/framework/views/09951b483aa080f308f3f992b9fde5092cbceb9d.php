<?php $__env->startSection('content'); ?>


    <section class="login-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-lg-offset-3 col-md-6 col-md-offset-3 col-sm-12">
                    <div class="login-form">

                        <div class="login-title text-center"><?php echo e($language->forgot_password); ?></div>

                        <form method="POST" action="<?php echo e(route('user.forgotpass.submit')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon">
                                        <i class="fa fa-envelope"></i>
                                    </div>
                                    <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" placeholder="Type Email Address" required>
                                </div>
                            </div>

                            <div id="resp">
                                <?php if(Session::has('success')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <?php echo e(Session::get('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('error')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <?php echo e(Session::get('error')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button type="submit" class="btn login-btn" name="button"><?php echo e($language->submit); ?></button>
                                <hr>
                                <p><a href="<?php echo e(route('user.login')); ?>" class="col-md-12">Already Have Account? Login</a></p>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>