<?php $__env->startSection('content'); ?>

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2>Change Password</h2>
                                    </div>
                                    <hr/>
                                    <div id="response" class="col-md-12">
                                        <?php if(Session::has('message')): ?>
                                            <div class="alert alert-success alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <?php echo e(Session::get('message')); ?>

                                            </div>
                                        <?php endif; ?>
                                        <?php if(Session::has('error')): ?>
                                            <div class="alert alert-danger alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <?php echo e(Session::get('error')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="<?php echo action('UserProfileController@changepass',['id' => $user->id]); ?>" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_current_password">Current Password*</label>
                                            <div class="col-sm-8">
                                                <input type="password" class="form-control" name="cpass" id="admin_current_password" placeholder="Current Password" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_new_password">New Password *</label>
                                            <div class="col-sm-8">
                                                <input type="password" class="form-control" name="newpass" id="admin_new_password" placeholder="New Password" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="admin_retype_password">Re-Type New Password *</label>
                                            <div class="col-sm-8">
                                                <input type="password" class="form-control" name="renewpass" id="admin_retype_password" placeholder="Re-Type New Password" required>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn btn-success add-product_btn">Change Password</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.includes.masterpage-user', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>