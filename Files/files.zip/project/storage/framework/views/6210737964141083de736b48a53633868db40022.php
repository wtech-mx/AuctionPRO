<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($pagename); ?></h1>
                </div>
            </div>

        </div>


    </section>


    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <div id="allcamps">
                    <?php $__empty_1 = true; $__currentLoopData = $auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div class="col-xs-12 col-sm-6 col-md-4">
                            <div class="package-list wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                                <a href="<?php echo e(url('/')); ?>/auction/<?php echo e($auction->id); ?>">
                                    <div class="package-thumb">
                                        <img width="800" height="570" src="<?php echo e(url('/assets/images/auction')); ?>/<?php echo e($auction->feature_image); ?>" class="" alt="1">
                                    </div>
                                    <div class="package-info text-center">

                                        <h4 class="">$<?php echo e($auction->price); ?></h4>
                                        <h3><?php echo e($auction->title); ?></h3>
                                        <h4 class="">Highest Bid: $<?php echo e(\App\Bid::maxBid($auction->id)); ?></h4>

                                        <div class="row">
                                            <div class="col-md-4 col-sm-4 col-xs-4 small-box">
                                                <b><?php echo e(\App\Bid::countBid($auction->id)); ?></b>
                                                <span>Bids</span>
                                            </div>
                                            <div class="col-md-4 col-sm-4 col-xs-4 small-box">
                                                <b><?php echo e($auction->condition); ?></b>
                                                <span>Condition</span>
                                            </div>
                                            <div class="col-md-4 col-sm-4 col-xs-4 small-box">
                                                <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                                    <b><?php echo e(0); ?></b>
                                                <?php else: ?>
                                                    <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                                <?php endif; ?>
                                                <span>Days Left</span>
                                            </div>

                                        </div>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="col-md-12">
                            <h4>No Auction Found in this Category.</h4>
                        </div>
                    <?php endif; ?>
                    <div class='col-md-12 margintop'></div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>