

<?php $__env->startSection('content'); ?>


    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard add-product-1 area -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2>Update Testimonial</h2>
                                        <a href="<?php echo url('admin/testimonial'); ?>" class="add-back-btn"><i class="fa fa-arrow-left"></i> back</a>
                                    </div>
                                    <hr/>
                                    <form method="POST" action="<?php echo action('TestimonialController@update',['id'=>$testimonial->id]); ?>" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <input type="hidden" name="_method" value="PATCH">
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="clients_review">Client's Review*</label>
                                            <div class="col-sm-8">
                                                <textarea name="review" id="clients_review" class="form-control" placeholder="review text" style="resize: vertical;" required><?php echo e($testimonial->review); ?></textarea>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="clients_name">Client's Name*</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="client" id="clients_name" value="<?php echo e($testimonial->client); ?>" placeholder="e.g John" required>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="clients_designation">Client's Designation*</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="designation" id="clients_designation" value="<?php echo e($testimonial->designation); ?>" placeholder="e.g CEO" required>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn btn-success add-product_btn">Update Testimonial</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard add-product-1 area -->


                </div>
            </div>
        </div>
    </div>


    
        
            

                
                
                    
                        
                    
                    
                    
                
                
                
                    
                        
                        
                            
                            
                            
                                

                                
                                
                                    
                                
                            
                            
                                

                                
                                
                                    
                                
                            
                            
                                

                                
                                
                                    
                                
                            
                            
                            
                                
                                    
                                
                            
                        
                    
                
            
            
        
        
    
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.masterpage-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>