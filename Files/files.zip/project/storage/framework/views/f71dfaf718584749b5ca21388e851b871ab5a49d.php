<?php $__env->startSection('content'); ?>

<!-- <?php echo e(url('/assets/images/package')); ?>/<?php echo e($campaign->feature_image); ?> -->

    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 4% 0px 4% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($campaign->title); ?></h1>
                </div>
            </div>

        </div>
    </section>

    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <div class="col-md-8">

                    <div class="profile-section">
                        <div class="row">
                            <h3 class="no-margin">Campign Details</h3><hr>

                        <img src="<?php echo e(url('/assets/images/campaign/'.$campaign->feature_image)); ?>" style="max-width: 100%; margin-bottom: 15px;">

                        <div class="video-container">
                            <?php echo \App\Campaign::getVideo($campaign->id); ?>

                        </div>

                            <p><?php echo $campaign->description; ?></p>
                        </div> 
                    </div>
              
                    <div style="margin-bottom:20px;">
                        <?php if(!empty($ads728x90)): ?>
                        <div class="desktop-advert">
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                    </div>

                </div>
                <div class="col-md-4 contact-info">

                    <?php if(Session::has('pmail')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('pmail')); ?> </div>
                    <?php endif; ?>

                    <div class="col-md-12">
                        <h3 class="text-center">Donate</h3><hr>
                        <div class="row" style="margin-bottom: 20px;">
                            <div>Created by: <br>
                                <strong class="cby"><?php echo e($campaign->createdby->name); ?></strong></div>
                                <?php echo e($campaign->createdby->country); ?>

                        </div>
                        <div class="row">
                                <span class="pull-left">
                                    <b>$<?php echo e($donations); ?></b>
                                     Funded of 
                                     <b>$<?php echo e($campaign->goal); ?></b>
                                     Goal
                                </span>
                            </div>

                                <div class="progress">
                                  <div class="progress-bar genius-bar" role="progressbar" aria-valuenow="<?php echo e(round($percent)); ?>"
                                  aria-valuemin="0" aria-valuemax="100" style="width:<?php echo e(round($percent)); ?>%">
                                      <?php echo e(round($percent)); ?>%
                                  </div>
                                </div>
                            <div class="row">
                                <span class="pull-left">
                                    <?php if(((strtotime($campaign->end_date)-time())/86400) < 0): ?>
                                        <b><?php echo e(0); ?></b>
                                    <?php else: ?>
                                        <b><?php echo e(ceil((strtotime($campaign->end_date)-time())/86400)); ?></b>
                                        <?php endif; ?>
                                        Days Left
                                </span>
                                <span class="pull-right">
                                    <b><?php echo e(\App\Donation::getDonations($campaign->id)); ?></b>
                                     Donations
                                </span>
                            </div>
                            <hr>
                        <div class="row">
                            <div class="profile-group">
                                <!-- AddToAny BEGIN -->
                                <div class="a2a_kit a2a_kit_size_40 a2a_default_style">
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_twitter"></a>
                                    <a class="a2a_button_google_plus"></a>
                                    <a class="a2a_button_linkedin"></a>
                                    <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                                </div>
                                <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <!-- AddToAny END -->
                            </div>
                    </div>

            <form action="<?php echo e(action('FrontEndController@donate' , ['id'=>$campaign->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group row" style="margin-bottom: 10px;">
                                <label class="">Donate Amount:</label>
                                <div>
                                    <input type="text" id="donation"  pattern="[0-9]+(\.[0-9]{0,2})?%?"
                                           title="Price must be a numeric or up to 2 decimal places." name="amount" class="form-control costs" value="<?php echo e($campaign->default_amount); ?>" required>
                                </div>
                            </div>
                            <?php if($campaign->preloaded_amount != ""): ?>
                            <div class="btn-group" style="margin-bottom: 10px;">
                                <?php $__empty_1 = true; $__currentLoopData = explode(',',$campaign->preloaded_amount); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $preload): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <button type="button" class="btn btn-default pre" value="<?php echo e($preload); ?>">$<?php echo e($preload); ?></button>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <?php endif; ?>
                            </div>
                            <?php endif; ?>
                            <div class="form-group text-center">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-ocean btn-block"> Donate Now</button>
                                </div>
                            </div>

                        </form>
                    </div>

                    <div class="col-md-12 text-center" style="margin-top: 20px;">
                        <?php if(!empty($ads300x250)): ?>
                        <div class="desktop-advert">
                            <?php if($ads300x250->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x250->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x250->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    
        
        
        
        
        
        
    
    $(".pre").click(function () {
        var val = $(this).val();
        $("#donation").val(val);
    })


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>