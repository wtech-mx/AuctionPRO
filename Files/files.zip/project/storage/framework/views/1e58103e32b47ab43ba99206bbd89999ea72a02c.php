<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1>All Tour Packages</h1>
                </div>
            </div>

        </div>
    </section>

    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xs-12 col-sm-12 col-md-4">
                        <div class="package-list wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
                            <a href="<?php echo e(url('/')); ?>/package/<?php echo e($package->id); ?>">
                                <div class="package-thumb">
                                    <img width="800" height="570" src="<?php echo e(url('/assets/images/package')); ?>/<?php echo e($package->feature_image); ?>" class="" alt="1">
                                </div>
                                <div class="package-info">
                                    <h3><?php echo e($package->title); ?></h3>
                                    <p><?php echo e(substr(strip_tags($package->description), 0, 100)); ?></p>
                                    <span class="pull-left">
                                <b>Date:</b> <?php echo e(date('d M',strtotime($package->start_date))); ?> - <?php echo e(date('d M',strtotime($package->return_date))); ?>

                            </span>
                                    <span class="pull-right price">$<?php echo e($package->cost_adult); ?></span>
                                </div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>