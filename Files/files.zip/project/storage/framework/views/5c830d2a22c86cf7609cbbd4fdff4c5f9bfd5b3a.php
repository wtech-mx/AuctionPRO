<?php $__env->startSection('content'); ?>

<!-- Starting of Auctions bid area -->
<div class="section-padding auctions-bid-header-section overlay text-center wow fadeInUp" style="background-image: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>);">
    <div class="container">
        <div class="row">
            <h1><?php echo e($auction->title); ?></h1>
        </div>
    </div>
</div>
<!-- Ending of Auctions bid area -->

<!-- Starting of Auctions bid amount area -->
<div class="auction-bid-area wow fadeInUp">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="auction-left-content">
                    <div class="auction-bid-carousel-area">
                        <div id="gallery" style="display:none;">
                            <img alt="Image 1 Title" src="<?php echo e(url('/assets/images/auction/'.$auction->feature_image)); ?>"
                                 data-image="<?php echo e(url('/assets/images/auction/'.$auction->feature_image)); ?>"
                                 data-description="Image 1 Description">
                            <?php $__currentLoopData = $gallerys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <img alt="Image 2 Title" src="<?php echo e(url('/assets/images/gallery/'.$gallery->image)); ?>"
                                     data-image="<?php echo e(url('/assets/images/gallery/'.$gallery->image)); ?>"
                                     data-description="Image 2 Description">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <div class="auction-bid-ad-area">
                        <?php if(!empty($ads728x90)): ?>
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                    <div class="auction-bid-description-area">
                        <ul class="nav nav-tabs">
                            <li class="active"><a data-toggle="tab" href="#description">Description</a></li>
                            <li><a data-toggle="tab" href="#bidHistory">Bid History</a></li>
                        </ul>
                        <div class="tab-content">
                            <div id="description" class="tab-pane fade in active">
                                <p><?php echo $auction->description; ?></p>
                            </div>
                            <div id="bidHistory" class="tab-pane fade">
                                <div class="table-responsive">
                                    <table id="auction-table" class="table table-striped table-hover products dt-responsive" cellspacing="0" width="100%">
                                        <thead>
                                        <tr>
                                            <th>Bidder</th>
                                            <th>Bid Amount</th>
                                            <th>Date</th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td><?php echo e($bid->bidder->name); ?></td>
                                                <td>$<?php echo e($bid->bid_amount); ?></td>
                                                <td><?php echo e($bid->created_at); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                            <tr>
                                                <td colspan="3">No Bid Placed Yet.</td>
                                            </tr>
                                        <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="auction-bid-ad-area">
                            <?php if(!empty($ads728x90)): ?>
                                <?php if($ads728x90->type == "banner"): ?>
                                    <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                        <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                    </a>
                                <?php else: ?>
                                    <?php echo $ads728x90->script; ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="auction-bid-rightside">
                    <div class="auction-bid-intro">
                        <div class="auction-bid-singleintro">
                            <p><strong><?php echo e($language->created_by); ?>:</strong></p>
                            <p><?php echo e($auction->createdby->name); ?></p>
                        </div>
                        <div class="auction-bid-singleintro">
                            <p><strong><?php echo e($language->conditions); ?>:</strong></p>
                            <p><?php echo e($auction->condition); ?></p>
                        </div>
                        <div class="auction-bid-singleintro">
                            <p><strong><?php echo e($language->highest_bid); ?>:</strong></p>
                            <p><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Bid::maxBid($auction->id)); ?></p>
                        </div>
                        <div class="auction-bid-singleintro">
                            <p><strong><?php echo e($language->buy_now); ?>:</strong></p>
                            <p><?php echo e($settings[0]->currency_sign); ?><?php echo e($auction->price); ?></p>
                        </div>
                    </div>

                    <div class="auction-bid-limit text-center">
                        <p>
                            <i class="fa fa-clock-o"></i>
                            <span>
                                <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                    <b><?php echo e(0); ?></b>
                                <?php else: ?>
                                    <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                <?php endif; ?>
                                    <?php echo e($language->days_left); ?>

                            </span>
                        </p>
                        <p><i class="fa fa-gavel"></i> <span><?php echo e(\App\Bid::countBid($auction->id)); ?> <?php echo e($language->bids); ?></span></p>
                    </div>


                    <div class="social-sharing text-center">
                        <!-- AddToAny BEGIN -->
                        <div class="a2a_kit a2a_kit_size_40 a2a_default_style">
                            <a class="a2a_button_facebook"></a>
                            <a class="a2a_button_twitter"></a>
                            <a class="a2a_button_google_plus"></a>
                            <a class="a2a_button_linkedin"></a>
                            <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                        </div>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                        <!-- AddToAny END -->
                    </div>

                    <div class="auction-form-area">
                        <form action="<?php echo e(action('FrontEndController@bid' , ['id'=>$auction->id])); ?>" method="get">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label for="bid-amount"><?php echo e($language->amount); ?>(<?php echo e($settings[0]->currency_code); ?>):</label>
                                <input type="text" id="bid-amount" pattern="[0-9]+(\.[0-9]{0,2})?%?"
                                       title="Price must be a numeric or up to 2 decimal places." name="amount" class="form-control" placeholder="" required>
                            </div>
                            <div class="col-md-12">

                                <?php if(Session::has('error')): ?>
                                    <div class="alert alert-danger alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <?php echo e(Session::get('error')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-success alert-dismissable">
                                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                        <?php echo e(Session::get('message')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <?php if($auction->status != "open"): ?>
                                    <button class="btn btn-block btn-primary" type="submit" disabled="disabled">Place Bid Now</button>
                                <?php else: ?>
                                    <button class="btn btn-block btn-primary" type="submit">Place Bid Now</button>
                                <?php endif; ?>

                            </div>

                            <div class="form-group">
                                <?php if(str_replace('$','',\App\Bid::maxBid($auction->id)) < $auction->price): ?>
                                    <?php if($auction->status != "open"): ?>
                                        <a href="javascript:;"><button class="btn btn-block btn-warning" type="submit" disabled>Buy Now</button></a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/auction/'.$auction->id.'/buy')); ?>"><button class="btn btn-block btn-warning" type="submit">Buy Now</button></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </form>
                    </div>

                    <div class="auction-recent-bid-area">
                        <hr>
                        <h2>Recent Bids</h2>
                        <hr>

                        <div class="auction-recent-bid-limit">
                            <?php $__empty_1 = true; $__currentLoopData = $recentbids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentbid): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <p><span class="bid-amount"><?php echo e($settings[0]->currency_sign); ?> <?php echo e($recentbid->bid_amount); ?></span></p>
                                <p><i class="fa fa-gavel"></i> <span><?php echo e($recentbid->bidder->name); ?> - <?php echo e($recentbid->updated_at->diffForHumans()); ?></span></p>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p>No Bid Placed Yet.</p>
                            <?php endif; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Ending of Auctions bid amount area -->

<!-- Starting of Related Auctions area -->
<div class="blog-area-wrapper related-auctions padding-top-0 wow fadeInUp">
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <div class="section-title">
                    <h2>Related Auctions</h2>
                </div>
            </div>
            <div class="col-md-12">
                <div class="owl-carousel blog-area-slider">
                    <?php $__currentLoopData = $popauctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $auction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/')); ?>/auction/<?php echo e($auction->id); ?>" class="single-featured-item">
                            <div class="featured-img">
                                <img class="featured-img" src="<?php echo e(url('/assets/images/auction')); ?>/<?php echo e($auction->feature_image); ?>" alt="">
                            </div>

                            <div class="featured-text">
                                <div class="featured-meta">
                                    <span class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e($auction->price); ?></span>
                                    <span><?php echo e($language->highest_bid); ?>  <strong class="featured-left"><?php echo e($settings[0]->currency_sign); ?><?php echo e(\App\Bid::maxBid($auction->id)); ?></strong></span>
                                </div>
                                <h4><?php echo e($auction->title); ?></h4>
                                <ul>
                                    <li><span><?php echo e(\App\Bid::countBid($auction->id)); ?></span> <?php echo e($language->bids); ?></li>
                                    <li><span><?php echo e($auction->condition); ?></span> <?php echo e($language->conditions); ?></li>
                                    <li><span>
                                            <?php if(((strtotime($auction->end_date)-time())/86400) < 0): ?>
                                                <b><?php echo e(0); ?></b>
                                            <?php else: ?>
                                                <b><?php echo e(ceil((strtotime($auction->end_date)-time())/86400)); ?></b>
                                            <?php endif; ?>
                                        </span>
                                        <?php echo e($language->days_left); ?>

                                    </li>
                                </ul>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Ending of Related Auctions area -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

    jQuery("#gallery").unitegallery({
        gallery_theme: "compact",
        gallery_autoplay: false,						//true / false - begin slideshow autoplay on start
        gallery_play_interval: 3000,				//play interval of the slideshow
        slider_scale_mode: "fit",
        slider_enable_play_button: false,	//show, hide the theme fullscreen button. The position in the theme is constant
        slider_enable_fullscreen_button: false			//show, hide the theme play button. The position in the theme is constant
    });



</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.masterpage', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>