<?php $__env->startSection('content'); ?>

    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard Service Section Title Text -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2>Blog Section Title Text</h2>
                                    </div>
                                    <hr/>
                                    <div id="response" class="col-md-12">
                                        <?php if(Session::has('message')): ?>
                                            <div class="alert alert-success alert-dismissable">
                                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                                <?php echo e(Session::get('message')); ?>

                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <form method="POST" action="<?php echo e(url('admin/blog/titles')); ?>" class="form-horizontal">
                                        <?php echo e(csrf_field()); ?>

                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="service_secttion_title">Blog Secttion Title *</label>
                                            <div class="col-sm-8">
                                                <input type="text" class="form-control" name="blog_title" id="service_secttion_title" placeholder="Blog Section Titles" value="<?php echo e($languages->blog_title); ?>">
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label class="control-label col-sm-3" for="service_secttion_text">Service Secttion Text *</label>
                                            <div class="col-sm-8">
                                                <textarea class="form-control" name="blog_text" id="service_secttion_text" placeholder="Blog Sections Text" style="resize: vertical;"><?php echo e($languages->blog_text); ?></textarea>
                                            </div>
                                        </div>
                                        <hr/>
                                        <div class="add-product-footer">
                                            <button name="addProduct_btn" type="submit" class="btn btn-success add-product_btn">update text</button>
                                        </div>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard Service Section Title Text -->


                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.masterpage-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>