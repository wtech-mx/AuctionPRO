<?php $__env->startSection('content'); ?>


    <div class="right-side">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <!-- Starting of Dashboard Withdraw Details -->
                    <div class="section-padding add-product-1">
                        <div class="row">
                            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                <div class="add-product-box">
                                    <div class="add-product-header">
                                        <h2>Withdraw Details</h2>
                                        <a href="<?php echo url()->previous(); ?>" class="add-newProduct-btn"><i class="fa fa-arrow-left"></i> Back</a>
                                    </div>
                                    <hr/>
                                    <div class="table-responsive order-details-table">
                                        <table class="table">
                                            <tr>
                                                <td width="30%"><strong>Customer ID#</strong></td>
                                                <td><?php echo e($withdraw->id); ?></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>Withdraw Amount:</strong></td>
                                                <td><strong style="color:green">$<?php echo e($withdraw->amount); ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>Withdraw Fee:</strong></td>
                                                <td><strong>$<?php echo e($withdraw->fee); ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>Withdraw Process Date:</strong></td>
                                                <td><?php echo e($withdraw->created_at); ?></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>Withdraw Status:</strong></td>
                                                <td><strong><?php echo e(ucfirst($withdraw->status)); ?></strong></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>User Name:</strong></td>
                                                <td><a href="<?php echo e(url('admin/users/'.$withdraw->userid->id)); ?>" target="_blank"><?php echo e($withdraw->userid->name); ?></a></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>Owner Email:</strong></td>
                                                <td><?php echo e($withdraw->userid->email); ?></td>
                                            </tr>
                                            <tr>
                                                <td width="30%"><strong>Owner Phone:</strong></td>
                                                <td><?php echo e($withdraw->userid->phone); ?></td>
                                            </tr>

                                            <tr>
                                                <td width="30%"><strong>Withdraw Method:</strong></td>
                                                <td><?php echo e($withdraw->method); ?></td>
                                            </tr>
                                            <?php if($withdraw->method != "Bank" && $withdraw->method != "Hand Cash"): ?>
                                                <tr>
                                                    <td width="30%"><strong><?php echo e($withdraw->method); ?> Email:</strong></td>
                                                    <td><?php echo e($withdraw->acc_email); ?></td>
                                                </tr>
                                            <?php elseif($withdraw->method == "Hand Cash"): ?>
                                                <tr>
                                                    <td width="30%"><strong>Cash Receiver Email:</strong></td>
                                                    <td><?php echo e($withdraw->acc_email); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="30%"><strong>Cash Receiver Phone:</strong></td>
                                                    <td><?php echo e($withdraw->acc_phone); ?></td>
                                                </tr>
                                            <?php else: ?>
                                                <tr>
                                                    <td width="30%"><strong><?php echo e($withdraw->method); ?> Account:</strong></td>
                                                    <td><?php echo e($withdraw->iban); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="30%"><strong>Account Name:</strong></td>
                                                    <td><?php echo e($withdraw->acc_name); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="30%"><strong>Country:</strong></td>
                                                    <td><?php echo e(ucfirst(strtolower($withdraw->country))); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="30%"><strong>Address:</strong></td>
                                                    <td><?php echo e($withdraw->address); ?></td>
                                                </tr>
                                                <tr>
                                                    <td width="30%"><strong><?php echo e($withdraw->method); ?> Swift Code:</strong></td>
                                                    <td><?php echo e($withdraw->swift); ?></td>
                                                </tr>
                                            <?php endif; ?>
                                            <tr>
                                                <td width="30%"><a href="accept/<?php echo e($withdraw->id); ?>" class="btn btn-success product-btn"><i class="fa fa-check-circle"></i> Accept</a></td>

                                                <td><a href="reject/<?php echo e($withdraw->id); ?>" class="btn btn-danger product-btn"><i class="fa fa-times-circle"></i> Reject</a></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ending of Dashboard User Details -->

                </div>
            </div>
        </div>
    </div>
    


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.masterpage-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>