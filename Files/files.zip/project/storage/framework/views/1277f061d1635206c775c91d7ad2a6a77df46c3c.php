<?php $__env->startSection('content'); ?>

<!-- <?php echo e(url('/assets/images/package')); ?>/<?php echo e($campaign->feature_image); ?> -->

    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 4% 0px 4% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <h1><?php echo e($campaign->title); ?></h1>
                </div>
            </div>

        </div>
    </section>

    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <div class="col-md-8">

                    <div class="profile-section">
                        <div class="row">

                            <div id="gallery" style="display:none;">

                                <img alt="Image 1 Title" src="<?php echo e(url('/assets/images/campaign/'.$campaign->feature_image)); ?>"
                                     data-image="<?php echo e(url('/assets/images/campaign/'.$campaign->feature_image)); ?>"
                                     data-description="Image 1 Description">

                                <img alt="Image 2 Title" src="<?php echo e(url('/assets/images/campaign/'.$campaign->feature_image)); ?>"
                                     data-image="<?php echo e(url('/assets/images/campaign/'.$campaign->feature_image)); ?>"
                                     data-description="Image 2 Description">

                            </div>

                        </div>
                    </div>
              
                    <div style="margin-bottom:20px;">
                        <?php if(!empty($ads728x90)): ?>
                        <div class="desktop-advert">
                            <?php if($ads728x90->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads728x90->redirect_url); ?>" target="_blank">
                                    <img class="banner-728x90" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads728x90->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads728x90->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>

                    </div>

                    <div class="information-blocks">
                        <div class="card">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#description" aria-controls="home" role="tab" data-toggle="tab">Description</a></li>
                                <li role="presentation"><a href="#bid-history" aria-controls="profile" role="tab" data-toggle="tab"> Bid History</a></li>
                            </ul>

                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="description">
                                    <p><?php echo $campaign->description; ?></p>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="bid-history">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <th>Firstname</th>
                                            <th>Lastname</th>
                                            <th>Email</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr>
                                            <td>John</td>
                                            <td>Doe</td>
                                            <td>john@example.com</td>
                                        </tr>
                                        <tr>
                                            <td>Mary</td>
                                            <td>Moe</td>
                                            <td>mary@example.com</td>
                                        </tr>
                                        <tr>
                                            <td>July</td>
                                            <td>Dooley</td>
                                            <td>july@example.com</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="col-md-4 contact-info">

                    <?php if(Session::has('pmail')): ?>
                        <div class="alert alert-success"> <?php echo e(Session::get('pmail')); ?> </div>
                    <?php endif; ?>

                    <div class="col-md-12">
                        
                        <div class="row" style="margin-bottom: 20px;">
                            <div><h4>Created by:<strong class="cby pull-right"><?php echo e($campaign->createdby->name); ?></strong></h4></div>
                            <div><h4>Item Condition:<strong class="cby pull-right">New</strong></h4></div>
                            <div><h4>Highest Bid:<strong class="cby pull-right">$21000</strong></h4></div>
                            <div><h4>Buy Now:<strong class="cby pull-right">$25000</strong></h4></div>
                        </div>

                            <div class="row">
                                <div>
                                    <h4>
                                        <i class="fa fa-clock-o fa-fw fa-2x"></i>
                                        <?php if(((strtotime($campaign->end_date)-time())/86400) < 0): ?>
                                            <b><?php echo e(0); ?></b>
                                        <?php else: ?>
                                            <b><?php echo e(ceil((strtotime($campaign->end_date)-time())/86400)); ?></b>
                                        <?php endif; ?>
                                        Days Left
                                    </h4>
                                </div>

                                <div>
                                    <h4>
                                        <i class="fa fa-check-circle fa-fw fa-2x"></i>
                                        21 Bids
                                    </h4>
                                </div>

                            </div>

                            <hr>
                        <div class="row">
                            <div class="profile-group">
                                <!-- AddToAny BEGIN -->
                                <div class="a2a_kit a2a_kit_size_40 a2a_default_style">
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_twitter"></a>
                                    <a class="a2a_button_google_plus"></a>
                                    <a class="a2a_button_linkedin"></a>
                                    <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                                </div>
                                <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <!-- AddToAny END -->
                            </div>
                        </div>

                    <form action="<?php echo e(action('FrontEndController@donate' , ['id'=>$campaign->id])); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <div class="form-group row" style="margin-bottom: 10px;">
                                <label class="">Donate Amount(USD):</label>
                                <div>
                                    <input type="text" id="donation"  pattern="[0-9]+(\.[0-9]{0,2})?%?"
                                           title="Price must be a numeric or up to 2 decimal places." name="amount" class="form-control costs" value="<?php echo e($campaign->default_amount); ?>" required>
                                </div>
                            </div>
                            
                            
                                
                                    
                                
                                
                            
                            
                            <div class="form-group text-center">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-ocean btn-block"> Place Bid Now</button>
                                </div>
                            </div>
                            <div class="col-md-12"><h3 class="text-center">Or</h3></div>
                            <div class="form-group text-center">
                                <label class="col-md-3 control-label"></label>
                                <div class="col-md-6">
                                    <button type="submit" class="btn btn-ocean btn-block"> Buy Now</button>
                                </div>
                            </div>

                        </form>

                        <div class="row">
                            <div class="col-md-12" style="padding: 0;">
                                <hr>
                                <h3>Recent Bids</h3>
                                <hr>
                                <div class="bid-recent">
                                    <span>$ 10000.00</span>
                                    <p><i class="fa fa-check-circle"></i>  username - 5 days ago</p>
                                </div>
                                <div class="bid-recent">
                                    <span>$ 10000.00</span>
                                    <p><i class="fa fa-check-circle"></i>  username - 5 days ago</p>
                                </div>
                                <div class="bid-recent">
                                    <span>$ 10000.00</span>
                                    <p><i class="fa fa-check-circle"></i>  username - 5 days ago</p>
                                </div>
                                <div class="bid-recent">
                                    <span>$ 10000.00</span>
                                    <p><i class="fa fa-check-circle"></i>  username - 5 days ago</p>
                                </div>

                            </div>
                        </div>


                    </div>

                    <div class="col-md-12 text-center" style="margin-top: 20px;">
                        <?php if(!empty($ads300x250)): ?>
                        <div class="desktop-advert">
                            <?php if($ads300x250->type == "banner"): ?>
                                <a class="ads" href="<?php echo e($ads300x250->redirect_url); ?>" target="_blank">
                                    <img class="banner-300x250" src="<?php echo e(url('/')); ?>/assets/images/ads/<?php echo e($ads300x250->banner_file); ?>" alt="Advertisement">
                                </a>
                            <?php else: ?>
                                <?php echo $ads300x250->script; ?>

                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-12">

                    <h3>Related Auctions</h3>

                </div>
            </div>


        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

    jQuery("#gallery").unitegallery({
        gallery_theme: "compact",
        gallery_autoplay: false,						//true / false - begin slideshow autoplay on start
        gallery_play_interval: 3000,				//play interval of the slideshow
        slider_enable_play_button: false,	//show, hide the theme fullscreen button. The position in the theme is constant
        slider_enable_fullscreen_button: false			//show, hide the theme play button. The position in the theme is constant
    });

    $(".pre").click(function () {
        var val = $(this).val();
        $("#donation").val(val);
    })


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>